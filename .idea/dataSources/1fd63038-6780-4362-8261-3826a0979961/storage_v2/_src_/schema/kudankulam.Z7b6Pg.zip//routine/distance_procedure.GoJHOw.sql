create procedure distance_procedure(IN dev_id text, IN sf_time date, IN ef_time date, IN table_r varchar(100))
  BEGIN

SET @LastLat:= 0;
SET @LastLon:= 0;
SET @L:= 0;

SET @CUR_DIS:= 0; 
SET @DIS :=0.000;

 	
SET @t0:=CONCAT("create  temporary table if not exists distance_temp
(
`id` int(11) NOT NULL AUTO_INCREMENT,
device_id bigint(20) NOT NULL DEFAULT '0',
`lat_message` decimal(11,8) NOT NULL DEFAULT '0.00000000',
`lon_message` decimal(11,8) NOT NULL DEFAULT '0.00000000',
`speed` decimal(5,2) NOT NULL DEFAULT '0.00',
`fixTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
distance decimal(5,2) NOT NULL DEFAULT '0.00',
LastLat decimal(11,8) NOT NULL DEFAULT '0.00000000',
LastLon decimal(11,8) NOT NULL DEFAULT '0.00000000',
DIS decimal(5,2) NOT NULL DEFAULT '0.00',
L int(11) NOT NULL DEFAULT '0',
 PRIMARY KEY (`id`)
)");

PREPARE stmt0 from @t0;
EXECUTE stmt0;
DEALLOCATE PREPARE stmt0; SET @t1:= CONCAT("INSERT INTO `distance_temp`(  `device_id`, `lat_message`, `lon_message`, `speed`, `fixTime`, `distance`, `LastLat`, `LastLon`, `DIS`, `L`) SELECT  `device_id`, `lat_message`, `lon_message`, `speed`,fixTime,
@CUR_DIS:=(IF(@L=0 ,0 ,3959 * acos( cos( radians(IF(@L=0 ,`lat_message`,@LastLat )) ) 
      * cos( radians(lat_message) ) 
      * cos( radians(lon_message) - radians(IF(@L=0 ,`lat_message`,@LastLon ))) + sin(radians(IF(@L=0 ,`lat_message`,@LastLat )))
      * sin( radians(lat_message) ) ) )) AS distance,@LastLat:=`lat_message`,@LastLon:=`lon_message`,@DIS:=(@DIS+@CUR_DIS) ,@L:=1 FROM ", table_r ," WHERE 1 and device_id ='", dev_id ,"' and fixTime >= '", sf_time ,"' and fixTime<='", ef_time ,"'    order by fixTime asc   ");
PREPARE stmt1 from @t1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 



                

                
SET @t2="SELECT device_id,DATE(fixTime) AS date_at, SUM(distance) AS distance ,count(device_id) as pings FROM   distance_temp GROUP BY DATE(fixTime)
 ORDER BY fixTime";
PREPARE stmt2 from @t2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2; 

END;

