create procedure get_current_location(IN tbl_name varchar(50), IN dev_id bigint, IN sf_time varchar(20),
                                      IN ef_time  varchar(20), IN data_bse varchar(50))
  BEGIN

set @lat='';
set @lon='';
set @dis=0.0;
set @dis_sum= 0.0;


SET @t1= CONCAT("SELECT case when @lat='' then @lat:=lat_message end, case when @lon='' then @lon:=`lon_message` end, `device_id`,`fixTime`,`lat_message`,`lon_message`,@lat as 'pre_lat_message', @lon as 'pre_lon_message' ,speed,cardinal_head,
				@dis:=111.1111 * DEGREES(ACOS(COS(RADIANS(@lat))
						 * COS(RADIANS(lat_message))
						 * COS(RADIANS(@lon - lon_message))
						 + SIN(RADIANS(@lat))
						 * SIN(RADIANS(lat_message)))) as 'distance_travelled',@dis_sum as 'cumulative',
				@lat:=lat_message,@lon:=lon_message ,@dis_sum:= @dis_sum+@dis  FROM ",data_bse,".",tbl_name," WHERE 1 and fixTIme between '", sf_time, "' and '", ef_time,"' and device_id= ", dev_id," and speed!=0 order by `device_id`,`fixTime` asc");

	PREPARE stmt3 from @t1;
EXECUTE stmt3;
DEALLOCATE PREPARE stmt3; 
END;

