create procedure get_distance_report(IN tbl_name varchar(50), IN dev_id varchar(20), IN sf_time varchar(20),
                                     IN ef_time  varchar(20), IN data_bse varchar(50))
  BEGIN

END;

