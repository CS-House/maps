create procedure history_procedure(IN dev_id bigint, IN sf_time datetime, IN ef_time datetime, IN table_r varchar(100))
  BEGIN

SET @LastLat:= 0;
SET @LastLon:= 0;
SET @L:= 0;

SET @CUR_DIS:= 0; 
SET @DIS :=0.000;


SET @t1:= CONCAT("SELECT  `device_id`, `lat_message`, `lon_message`, `speed`,fixTime,
@CUR_DIS:=(IF(@L=0 ,0 ,3959 * acos( cos( radians(IF(@L=0 ,`lat_message`,@LastLat )) ) 
      * cos( radians(lat_message) ) 
      * cos( radians(lon_message) - radians(IF(@L=0 ,`lat_message`,@LastLon ))) + sin(radians(IF(@L=0 ,`lat_message`,@LastLat )))
      * sin( radians(lat_message) ) ) )) AS distance,@DIS,@LastLat:=`lat_message`,@LastLon:=`lon_message`,@DIS:=(@DIS+@CUR_DIS) ,@L:=1 FROM ", table_r ," WHERE 1 and device_id=", dev_id ," and fixTime between '", sf_time ,"' and '", ef_time ,"' and lat_message >0 and lon_message >0  order by fixTime asc    ");
PREPARE stmt1 from @t1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;

END;

