create procedure idle_procedure(IN dev_id bigint, IN sf_time datetime, IN ef_time datetime, IN table_r varchar(100))
  BEGIN

SET @t1:=CONCAT(" CREATE TEMPORARY  TABLE IF NOT EXISTS `idleData` (
                `id` int(11) NOT NULL AUTO_INCREMENT,
                `sno` int(11) NOT NULL,
                `lat` decimal(11,8) NOT NULL,
                lon decimal(11,8) NOT NULL,
                `fix` datetime NOT NULL,
                speed decimal(5,2) NOt NULL,
                slug int(11) NOT NULL,
                grp int(11) NOT NULL,
                PRIMARY KEY (`id`))"," ");

PREPARE stmt1 from @t1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


SET @t2:="TRUNCATE TABLE idleData";
PREPARE stmt2 from @t2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2; 



SET @j:=1;
SET @k:=0;

SET @t0:=CONCAT("insert into idleData (sno,lat,lon,fix,speed,slug,grp)
select l.s_no,l.lat_message,l.lon_message,l.fixTime,speed,case when (l.Speed>0) then @k:=1 else @k:=0 end as slug,case when @k=0 then @j else @j:=@j+1 end as grp from ", table_r, " l where 1 and l.device_id='", dev_id ,"' and l.fixTime >='", sf_time ,"' and l.fixTime <='",ef_time,"' order by l.fixTime asc");

PREPARE stmt0 from @t0;
EXECUTE stmt0;
DEALLOCATE PREPARE stmt0; 


SET @t3:=CONCAT("SELECT min(`fix`) as start,max(`fix`) as end,  TIMESTAMPDIFF(MINUTE, min(`fix`), max(`fix`)) as diff,lat ,lon FROM `idleData`  where `speed` ='0.00' group by `grp`");
PREPARE stmt3 from @t3;
EXECUTE stmt3;
DEALLOCATE PREPARE stmt3; 





END;

