create definer = rootone@`%` event eDaily
  on schedule
    every '1' DAY
      starts '2017-12-31 00:00:00'
      ends '2019-06-26 05:30:00'
  enable
  comment 'Saves total number of sessions then clears the table each day'
do
  BEGIN
			
			INSERT IGNORE INTO `location_history_june_2018`(`device_id`, `created_date`, `lat_message`, `lon_message`, `speed`, `cardinal_head`, `distance_travelled`, `pre_lat_message`, `pre_lon_message`, `time_difference`, `port`, `fixTime`, `attributes`, `updated_date`) SELECT `device_id`, `created_date`, `lat_message`, `lon_message`, `speed`, `cardinal_head`, `distance_travelled`, `pre_lat_message`, `pre_lon_message`, `time_difference`, `port`, `fixTime`, `attributes`, `updated_date` FROM `location_history_current`  WHERE 1;

			TRUNCATE TABLE  `location_history_current`;
			TRUNCATE TABLE  `log`;
			END;

