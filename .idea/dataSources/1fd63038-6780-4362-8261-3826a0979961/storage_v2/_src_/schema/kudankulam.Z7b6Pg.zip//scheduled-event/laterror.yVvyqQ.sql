create definer = root@localhost event Laterror
  on schedule
    every '2' MINUTE
      starts '2018-03-06 00:00:00'
      ends '2022-03-06 00:00:00'
  enable
do
  UPDATE device_status SET lat_message=8.16616, lon_message=77.70612 where lat_message < 5;

