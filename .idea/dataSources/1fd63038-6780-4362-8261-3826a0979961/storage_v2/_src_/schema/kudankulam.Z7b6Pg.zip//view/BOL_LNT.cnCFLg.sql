create view BOL_LNT as select
                         1                               AS `bank_id`,
                         1                               AS `plant_id`,
                         `kudankulam`.`BOLLE`.`DATA`     AS `DATA`,
                         `kudankulam`.`BOLLE`.`M3`       AS `M3`,
                         `kudankulam`.`BOLLE`.`COD_DST`  AS `COD_DST`,
                         `kudankulam`.`BOLLE`.`NOME_DST` AS `NOME_DST`,
                         `kudankulam`.`BOLLE`.`COD_BET`  AS `COD_BET`,
                         `kudankulam`.`BOLLE`.`COD_BET`  AS `TAR_BET`,
                         `kudankulam`.`BOLLE`.`AUT_BET`  AS `AUT_BET`,
                         `kudankulam`.`BOLLE`.`COD_FRM`  AS `COD_FRM`,
                         `kudankulam`.`BOLLE`.`MOD_DATA` AS `MOD_DATA`,
                         `kudankulam`.`BOLLE`.`MOD_OPE`  AS `MOD_OPE`,
                         `kudankulam`.`BOLLE`.`IDX`      AS `IDX`,
                         `kudankulam`.`BOLLE`.`ID_IMP`   AS `ID_IMP`
                       from `kudankulam`.`BOLLE`
                       where 1
                       union select
                               1                                  AS `bank_id`,
                               2                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p2`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p2`.`M3`       AS `M3`,
                               `kudankulam`.`BOLLE_p2`.`IND1_DST` AS `COD_DST`,
                               `kudankulam`.`BOLLE_p2`.`NOME_DST` AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p2`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p2`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p2`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p2`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p2`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p2`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p2`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p2`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p2`
                             where 1
                       union select
                               2                                  AS `bank_id`,
                               3                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p3`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p3`.`M3`       AS `M3`,
                               `kudankulam`.`BOLLE_p3`.`IND1_DST` AS `COD_DST`,
                               `kudankulam`.`BOLLE_p3`.`NOME_DST` AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p3`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p3`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p3`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p3`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p3`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p3`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p3`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p3`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p3`
                             where 1
                       union select
                               2                                  AS `bank_id`,
                               4                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p4`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p4`.`M3`       AS `M3`,
                               `kudankulam`.`BOLLE_p4`.`IND1_DST` AS `COD_DST`,
                               `kudankulam`.`BOLLE_p4`.`NOME_DST` AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p4`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p4`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p4`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p4`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p4`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p4`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p4`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p4`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p4`
                             where 1
                       union select
                               2                                  AS `bank_id`,
                               5                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p5`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p5`.`M3`       AS `M3`,
                               `kudankulam`.`BOLLE_p5`.`IND1_DST` AS `COD_DST`,
                               `kudankulam`.`BOLLE_p5`.`NOME_DST` AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p5`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p5`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p5`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p5`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p5`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p5`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p5`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p5`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p5`
                             where 1
                       union select
                               1                                  AS `bank_id`,
                               6                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p6`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p6`.`M3`       AS `M3`,
                               'Right Bank'                       AS `COD_DST`,
                               'L&T'                              AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p6`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p6`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p6`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p6`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p6`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p6`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p6`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p6`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p6`
                             where 1
                       union select
                               1                                  AS `bank_id`,
                               7                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p7`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p7`.`M3`       AS `M3`,
                               'Right Bank'                       AS `COD_DST`,
                               'L&T'                              AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p7`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p7`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p7`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p7`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p7`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p7`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p7`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p7`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p7`
                             where 1
                       union select
                               2                                  AS `bank_id`,
                               8                                  AS `plant_id`,
                               `kudankulam`.`BOLLE_p8`.`DATA`     AS `DATA`,
                               `kudankulam`.`BOLLE_p8`.`M3`       AS `M3`,
                               'Right Bank'                       AS `COD_DST`,
                               'L&T'                              AS `NOME_DST`,
                               `kudankulam`.`BOLLE_p8`.`COD_BET`  AS `COD_BET`,
                               `kudankulam`.`BOLLE_p8`.`COD_BET`  AS `TAR_BET`,
                               `kudankulam`.`BOLLE_p8`.`AUT_BET`  AS `AUT_BET`,
                               `kudankulam`.`BOLLE_p8`.`COD_FRM`  AS `COD_FRM`,
                               `kudankulam`.`BOLLE_p8`.`MOD_DATA` AS `MOD_DATA`,
                               `kudankulam`.`BOLLE_p8`.`MOD_OPE`  AS `MOD_OPE`,
                               `kudankulam`.`BOLLE_p8`.`IDX`      AS `IDX`,
                               `kudankulam`.`BOLLE_p8`.`ID_IMP`   AS `ID_IMP`
                             from `kudankulam`.`BOLLE_p8`
                             where 1;

